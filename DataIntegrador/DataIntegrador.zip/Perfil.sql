﻿CREATE TABLE [dbo].[Perfil]
(
	[Nombre] VARCHAR(50) NOT NULL PRIMARY KEY
)
