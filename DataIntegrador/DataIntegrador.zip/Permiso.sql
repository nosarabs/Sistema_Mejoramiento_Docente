﻿CREATE TABLE [dbo].[Permiso]
(
	[Id] INT NOT NULL PRIMARY KEY,
	[Descripcion] VARCHAR(150) NULL
)
